/*
* TUser.java
* Copyright(C) 2017-2020 fendo��˾
* @date 2017-10-06
*/
package pojo;

import java.util.Date;

/**
 * @Description t_user����ʵ����
 * @version 1.0
 * @Author fendo
 * @Date 2017-10-06 15:43:50
 */
public class TUser {
    /**
     * @Fields id 
     */
    private String id;

    /**
     * @Fields name 
     */
    private String name;

    /**
     * @Fields password 
     */
    private String password;

    /**
     * @Fields idcard 
     */
    private String idcard;

    /**
     * @Fields email 
     */
    private String email;

    /**
     * @Fields addres 
     */
    private String addres;

    /**
     * @Fields mobile 
     */
    private String mobile;

    /**
     * @Fields highbloodpressure 
     */
    private Double highbloodpressure;

    /**
     * @Fields lowbloodpressure 
     */
    private Double lowbloodpressure;

    /**
     * @Fields idcardnum 
     */
    private Integer idcardnum;

    /**
     * @Fields createtime 
     */
    private Date createtime;

    /**
     * ��ȡ  �ֶ�:t_user.id
     *
     * @return t_user.id, 
     */
    public String getId() {
        return id;
    }

    /**
     * ����  �ֶ�:t_user.id
     *
     * @param id the value for t_user.id, 
     */
    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    /**
     * ��ȡ  �ֶ�:t_user.name
     *
     * @return t_user.name, 
     */
    public String getName() {
        return name;
    }

    /**
     * ����  �ֶ�:t_user.name
     *
     * @param name the value for t_user.name, 
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * ��ȡ  �ֶ�:t_user.password
     *
     * @return t_user.password, 
     */
    public String getPassword() {
        return password;
    }

    /**
     * ����  �ֶ�:t_user.password
     *
     * @param password the value for t_user.password, 
     */
    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    /**
     * ��ȡ  �ֶ�:t_user.idcard
     *
     * @return t_user.idcard, 
     */
    public String getIdcard() {
        return idcard;
    }

    /**
     * ����  �ֶ�:t_user.idcard
     *
     * @param idcard the value for t_user.idcard, 
     */
    public void setIdcard(String idcard) {
        this.idcard = idcard == null ? null : idcard.trim();
    }

    /**
     * ��ȡ  �ֶ�:t_user.email
     *
     * @return t_user.email, 
     */
    public String getEmail() {
        return email;
    }

    /**
     * ����  �ֶ�:t_user.email
     *
     * @param email the value for t_user.email, 
     */
    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    /**
     * ��ȡ  �ֶ�:t_user.addres
     *
     * @return t_user.addres, 
     */
    public String getAddres() {
        return addres;
    }

    /**
     * ����  �ֶ�:t_user.addres
     *
     * @param addres the value for t_user.addres, 
     */
    public void setAddres(String addres) {
        this.addres = addres == null ? null : addres.trim();
    }

    /**
     * ��ȡ  �ֶ�:t_user.mobile
     *
     * @return t_user.mobile, 
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * ����  �ֶ�:t_user.mobile
     *
     * @param mobile the value for t_user.mobile, 
     */
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    /**
     * ��ȡ  �ֶ�:t_user.highbloodpressure
     *
     * @return t_user.highbloodpressure, 
     */
    public Double getHighbloodpressure() {
        return highbloodpressure;
    }

    /**
     * ����  �ֶ�:t_user.highbloodpressure
     *
     * @param highbloodpressure the value for t_user.highbloodpressure, 
     */
    public void setHighbloodpressure(Double highbloodpressure) {
        this.highbloodpressure = highbloodpressure;
    }

    /**
     * ��ȡ  �ֶ�:t_user.lowbloodpressure
     *
     * @return t_user.lowbloodpressure, 
     */
    public Double getLowbloodpressure() {
        return lowbloodpressure;
    }

    /**
     * ����  �ֶ�:t_user.lowbloodpressure
     *
     * @param lowbloodpressure the value for t_user.lowbloodpressure, 
     */
    public void setLowbloodpressure(Double lowbloodpressure) {
        this.lowbloodpressure = lowbloodpressure;
    }

    /**
     * ��ȡ  �ֶ�:t_user.idcardnum
     *
     * @return t_user.idcardnum, 
     */
    public Integer getIdcardnum() {
        return idcardnum;
    }

    /**
     * ����  �ֶ�:t_user.idcardnum
     *
     * @param idcardnum the value for t_user.idcardnum, 
     */
    public void setIdcardnum(Integer idcardnum) {
        this.idcardnum = idcardnum;
    }

    /**
     * ��ȡ  �ֶ�:t_user.createtime
     *
     * @return t_user.createtime, 
     */
    public Date getCreatetime() {
        return createtime;
    }

    /**
     * ����  �ֶ�:t_user.createtime
     *
     * @param createtime the value for t_user.createtime, 
     */
    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }
}