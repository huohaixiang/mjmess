/**
 *    Copyright 2006-2016 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;

import java.util.Iterator;
import java.util.List;

import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.dom.OutputUtilities;
import org.mybatis.generator.api.dom.xml.Attribute;
import org.mybatis.generator.api.dom.xml.TextElement;
import org.mybatis.generator.api.dom.xml.XmlElement;
import org.mybatis.generator.codegen.mybatis3.ListUtilities;
import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;

/**
 * 
 * @author Jeff Butler
 * 
 */
public class UpdateByPrimaryKeyWithoutBLOBsElementGenerator extends
        AbstractXmlElementGenerator {

    private boolean isSimple;
    
    public UpdateByPrimaryKeyWithoutBLOBsElementGenerator(boolean isSimple) {
        super();
        //this.isSimple = isSimple;
    }

    
	@Override
	public void addElements(XmlElement parentElement) {
	
//		//update标签(方法最外层)
//		XmlElement answer = new XmlElement("update"); 
//		
//		//update标签的属性
//		answer.addAttribute(new Attribute("id", introspectedTable.getUpdateByPrimaryKeyStatementId())); //$NON-NLS-1$
//		answer.addAttribute(new Attribute("parameterType", "Map"));
//		
//		//把标签加进去
//		context.getCommentGenerator().addComment(answer);
//		StringBuilder sb = new StringBuilder();
//		sb.append("update "); 
//		sb.append(introspectedTable.getFullyQualifiedTableNameAtRuntime());
//		
//		//标签内容，即文本元素
//		answer.addElement(new TextElement(sb.toString()));
//		sb.setLength(0);
//		
//		
//		//set标签
//		XmlElement setElement = new XmlElement("set"); //$NON-NLS-1$
//		
//		
//		//获取数据库表中的所有字段
//		List <IntrospectedColumn> cols=introspectedTable.getAllColumns();
//		
//		//迭代
//		java.util.Iterator<IntrospectedColumn> iter =cols.iterator();
//		while (iter.hasNext()) {//迭代
//			//迭代到某一字段
//			IntrospectedColumn introspectedColumn = iter.next();
//			//if标签
//			XmlElement ifElement = new XmlElement("if"); //$NON-NLS-1$
//			//字段名
//			String str=MyBatis3FormattingUtilities
//			.getEscapedColumnName(introspectedColumn);
//			//if标签添加属性test，值为 字段 !=null and 字段!=''
//			ifElement.addAttribute(new Attribute("test",str+" != null and "+str+"!='' "));
//			//if标签内容 ，文本元素，给字段赋予即将修改的值
//			sb.append(MyBatis3FormattingUtilities
//			.getEscapedColumnName(introspectedColumn));
//			sb.append(" = "); //$NON-NLS-1$
//			sb.append(MyBatis3FormattingUtilities
//			.getParameterClause(introspectedColumn));
//			if (iter.hasNext()) {
//			sb.append(',');
//			}
//			//if标签添加上面的文本元素
//			ifElement.addElement(new TextElement(sb.toString()));
//			if (iter.hasNext()) {
//			sb.setLength(0);
//			OutputUtilities.xmlIndent(sb, 1);
//			}
//			setElement.addElement(ifElement);
//		}
//		
//		//where元素(修改的字段前提条件)
//		XmlElement whereElement =new XmlElement("where");
//		for (IntrospectedColumn introspectedColumn : introspectedTable.getPrimaryKeyColumns()) {//遍历表中字段进行判断
//			sb.setLength(0);
//			sb.append(MyBatis3FormattingUtilities
//			.getEscapedColumnName(introspectedColumn));
//			sb.append(" = "); //$NON-NLS-1$
//			sb.append(MyBatis3FormattingUtilities
//			.getParameterClause(introspectedColumn));
//			whereElement.addElement(new TextElement(sb.toString()));
//		}
//		
//		//方法中最外层xml元素 update元素添加set元素和where元素
//		answer.addElement(setElement);
//		answer.addElement(whereElement);
//		if (context.getPlugins().sqlMapUpdateByPrimaryKeyWithoutBLOBsElementGenerated(answer,introspectedTable)) {
//		   parentElement.addElement(answer);
//		}
	}
}
